param(
    [string]$ProjectRoot = "D:\Projects\TradingSystem",
    [string]$BaselineZip = "$env:USERPROFILE\Downloads\Trading_System_Specification_Pack_Baseline_v0.5.zip"
)

$ErrorActionPreference = "Stop"

Write-Host "Creating project folders at $ProjectRoot"

New-Item -ItemType Directory -Force -Path $ProjectRoot | Out-Null
New-Item -ItemType Directory -Force -Path "$ProjectRoot\docs\baseline-v0.5" | Out-Null
New-Item -ItemType Directory -Force -Path "$ProjectRoot\artifacts\poi" | Out-Null
New-Item -ItemType Directory -Force -Path "$ProjectRoot\artifacts\reports" | Out-Null
New-Item -ItemType Directory -Force -Path "$ProjectRoot\.claude\rules" | Out-Null

if (-not (Test-Path $BaselineZip)) {
    throw "Baseline ZIP not found: $BaselineZip"
}

Expand-Archive -Path $BaselineZip -DestinationPath "$ProjectRoot\docs\baseline-v0.5" -Force

Copy-Item -Path "$PSScriptRoot\CLAUDE.md" -Destination "$ProjectRoot\CLAUDE.md" -Force
Copy-Item -Path "$PSScriptRoot\START_PROMPT_PHASE_0_HE.md" -Destination "$ProjectRoot\START_PROMPT_PHASE_0_HE.md" -Force
Copy-Item -Path "$PSScriptRoot\IMPLEMENT_FIRST_TASK_PROMPT_HE.md" -Destination "$ProjectRoot\IMPLEMENT_FIRST_TASK_PROMPT_HE.md" -Force
Copy-Item -Path "$PSScriptRoot\.gitignore" -Destination "$ProjectRoot\.gitignore" -Force

Set-Location $ProjectRoot

if (-not (Test-Path "$ProjectRoot\.git")) {
    git init
}

Write-Host ""
Write-Host "Project prepared."
Write-Host "Next commands:"
Write-Host "  cd $ProjectRoot"
Write-Host "  code ."
Write-Host "  claude"
Write-Host ""
Write-Host "Paste the content of START_PROMPT_PHASE_0_HE.md into Claude Code."
